# Language Geometry Report

## Protocol

A ten-utterance dialogue is not a ten-point ID sample: PHD uses contextual token embeddings (50-510 points) inside one dialogue. Generation seeds are technical repeats aggregated within stimulus; only stimulus blocks support primary inference.

Gromov-style pooled word/n-gram analysis is separate from dialogue PHD and is not reported unless its predefined ladder is supported.

## Degeneration Panel

- `identity`: 2 dialogues, invalid PHD 0/2 (0.0%)
- `pca_1`: 2 dialogues, invalid PHD 0/2 (0.0%)
- `pca_128`: 2 dialogues, invalid PHD 0/2 (0.0%)
- `pca_2`: 2 dialogues, invalid PHD 0/2 (0.0%)
- `pca_32`: 2 dialogues, invalid PHD 0/2 (0.0%)
- `pca_8`: 2 dialogues, invalid PHD 0/2 (0.0%)

## PHD Diagnostics

- Flags: `{}`
- Primary PHD is shown only after the degeneration panel; invalid results are never imputed.
