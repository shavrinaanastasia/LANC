# Language Geometry Report

## Protocol

A ten-utterance dialogue is not a ten-point ID sample: PHD uses contextual token embeddings (50-510 points) inside one dialogue. Generation seeds are technical repeats aggregated within stimulus; only stimulus blocks support primary inference.

Gromov-style pooled word/n-gram analysis is separate from dialogue PHD and is not reported unless its predefined ladder is supported.

## Degeneration Panel

- `identity`: 72 dialogues, invalid PHD 0/72 (0.0%)
- `pca_1`: 72 dialogues, invalid PHD 0/72 (0.0%)
- `pca_128`: 72 dialogues, invalid PHD 0/72 (0.0%)
- `pca_2`: 72 dialogues, invalid PHD 0/72 (0.0%)
- `pca_32`: 72 dialogues, invalid PHD 0/72 (0.0%)
- `pca_8`: 72 dialogues, invalid PHD 0/72 (0.0%)

## PHD Diagnostics

- Flags: `{'TRUNCATED_TO_510': 1}`
- Primary PHD is shown only after the degeneration panel; invalid results are never imputed.
